<?php
/**
 * Shopify Success - Redirect terug naar Shopify na succesvolle betaling
 */

require_once 'config.php';

$shopDomain = $_GET['shop'] ?? 'jouw-winkel.myshopify.com';
$orderID = $_GET['order'] ?? '';

$success = false;
$transactionRef = '';
$amount = 0;

// Verwerk de response van myPOS
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $cnf = getMyPosConfig();
        $response = new \Mypos\IPC\Response($cnf);
        
        if ($response->validate()) {
            $success = true;
            $orderID = $response->getOrderID();
            $amount = $response->getAmount();
            $transactionRef = $response->getIPC_Trnref();
            
            // Log de succesvolle betaling
            file_put_contents(
                __DIR__ . '/shopify_payments.log',
                date('[Y-m-d H:i:s] ') . "Betaling succesvol - Order: {$orderID}, Bedrag: {$amount}, Ref: {$transactionRef}\n",
                FILE_APPEND
            );
        }
    } catch (Exception $e) {
        // Log error
        file_put_contents(
            __DIR__ . '/shopify_payments.log',
            date('[Y-m-d H:i:s] ') . "ERROR: " . $e->getMessage() . "\n",
            FILE_APPEND
        );
    }
}

// Bouw de Shopify redirect URL
// Je moet in Shopify een pagina maken die deze parameters accepteert
$shopifyReturnUrl = "https://{$shopDomain}/pages/payment-success?order_id=" . urlencode($orderID) . 
                    "&transaction=" . urlencode($transactionRef) . 
                    "&amount=" . urlencode($amount);

?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Betaling Verwerken...</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .container {
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            max-width: 500px;
            width: 100%;
            padding: 40px;
            text-align: center;
        }
        
        .spinner {
            width: 60px;
            height: 60px;
            border: 4px solid #f3f3f3;
            border-top: 4px solid #11998e;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto 20px;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        h1 {
            color: #333;
            margin-bottom: 10px;
            font-size: 24px;
        }
        
        p {
            color: #666;
            line-height: 1.6;
        }
        
        .success-icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            animation: scaleIn 0.5s ease;
        }
        
        @keyframes scaleIn {
            from { transform: scale(0); }
            to { transform: scale(1); }
        }
        
        .checkmark {
            width: 40px;
            height: 40px;
            border: 4px solid white;
            border-top: none;
            border-left: none;
            transform: rotate(45deg);
            margin-bottom: 10px;
        }
    </style>
    <?php if ($success): ?>
    <script>
        // Redirect na 3 seconden
        setTimeout(function() {
            window.location.href = '<?php echo htmlspecialchars($shopifyReturnUrl); ?>';
        }, 3000);
    </script>
    <?php endif; ?>
</head>
<body>
    <div class="container">
        <?php if ($success): ?>
            <div class="success-icon">
                <div class="checkmark"></div>
            </div>
            <h1>Betaling Geslaagd!</h1>
            <p>Je wordt teruggestuurd naar de winkel...</p>
            <p style="margin-top: 20px; font-size: 14px; color: #999;">
                Order: <?php echo htmlspecialchars($orderID); ?>
            </p>
        <?php else: ?>
            <div class="spinner"></div>
            <h1>Betaling Verwerken...</h1>
            <p>Even geduld, we verwerken je betaling.</p>
        <?php endif; ?>
    </div>
</body>
</html>
