<?php
/**
 * Callback Handler - myPOS stuurt hier notificaties naartoe
 * Dit wordt NIET door de klant bezocht maar door myPOS servers
 */

// Log alle inkomende requests voor debugging
$logFile = __DIR__ . '/mypos_callbacks.log';

// Log de inkomende data
file_put_contents(
    $logFile,
    date('[Y-m-d H:i:s] ') . "Callback ontvangen\n" . 
    print_r($_POST, true) . 
    "\n---\n",
    FILE_APPEND
);

require_once 'config.php';

try {
    $cnf = getMyPosConfig();
    $response = new \Mypos\IPC\Response($cnf);
    
    // Valideer de signature
    if ($response->validate()) {
        // Response is geldig!
        $orderID = $response->getOrderID();
        $amount = $response->getAmount();
        $currency = $response->getCurrency();
        $status = $response->getStatus(); // 0 = success, 1 = cancelled, 2 = declined, 3 = error
        $transactionRef = $response->getIPC_Trnref();
        
        // Log de succesvolle validatie
        file_put_contents(
            $logFile,
            date('[Y-m-d H:i:s] ') . "✓ Validatie geslaagd - Order: {$orderID}, Status: {$status}, Bedrag: {$amount} {$currency}\n",
            FILE_APPEND
        );
        
        // Hier verwerk je de betaling in je database
        // Bijvoorbeeld:
        /*
        if ($status == 0) {
            // Betaling succesvol
            updateOrderStatus($orderID, 'paid', $transactionRef);
            sendConfirmationEmail($orderID);
        } else {
            // Betaling mislukt
            updateOrderStatus($orderID, 'failed');
        }
        */
        
        // Stuur OK terug naar myPOS
        echo "OK";
        http_response_code(200);
        
    } else {
        // Validatie mislukt - mogelijk een fraude poging
        file_put_contents(
            $logFile,
            date('[Y-m-d H:i:s] ') . "✗ Validatie mislukt! Mogelijk fraude.\n",
            FILE_APPEND
        );
        
        http_response_code(400);
        echo "VALIDATION_FAILED";
    }
    
} catch (Exception $e) {
    // Log de error
    file_put_contents(
        $logFile,
        date('[Y-m-d H:i:s] ') . "ERROR: " . $e->getMessage() . "\n",
        FILE_APPEND
    );
    
    http_response_code(500);
    echo "ERROR";
}

/**
 * Voorbeeld functies voor database updates
 * Pas deze aan naar jouw database structuur
 */

/*
function updateOrderStatus($orderID, $status, $transactionRef = null) {
    // Voorbeeld met PDO
    $pdo = new PDO('mysql:host=localhost;dbname=jouw_database', 'username', 'password');
    
    $sql = "UPDATE orders SET status = :status, transaction_ref = :ref, updated_at = NOW() WHERE order_id = :order_id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':status' => $status,
        ':ref' => $transactionRef,
        ':order_id' => $orderID
    ]);
}

function sendConfirmationEmail($orderID) {
    // Verstuur een bevestigingsmail
    // mail(...);
}
*/
