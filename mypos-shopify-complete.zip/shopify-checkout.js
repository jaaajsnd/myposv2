/**
 * Shopify Custom Checkout Button
 * 
 * Plaats dit script in je Shopify theme (theme.liquid of cart.liquid)
 * Dit onderschept de checkout button en stuurt naar myPOS
 */

(function() {
    'use strict';
    
    // ⚠️ PAS DIT AAN NAAR JOUW RENDER URL!
    const MYPOS_API_URL = 'https://jouw-app-naam.onrender.com/shopify-checkout.php';
    
    // Wacht tot de pagina geladen is
    document.addEventListener('DOMContentLoaded', function() {
        
        // Zoek de checkout button(s)
        const checkoutButtons = document.querySelectorAll('button[name="checkout"], .checkout-button, [href*="/checkout"]');
        
        checkoutButtons.forEach(function(button) {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                // Toon loading state
                const originalText = button.textContent;
                button.textContent = 'Betaling voorbereiden...';
                button.disabled = true;
                
                // Haal cart data op
                fetch('/cart.js')
                    .then(response => response.json())
                    .then(cartData => {
                        
                        // Formatteer de data voor myPOS
                        const checkoutData = {
                            shop_domain: Shopify.shop,
                            total: (cartData.total_price / 100).toFixed(2), // Shopify geeft prijs in centen
                            currency: cartData.currency,
                            items: cartData.items.map(item => ({
                                title: item.product_title,
                                variant: item.variant_title,
                                quantity: item.quantity,
                                price: (item.price / 100).toFixed(2), // Prijs in centen naar euros
                                product_id: item.product_id,
                                variant_id: item.variant_id
                            })),
                            customer: {
                                email: cartData.email || '',
                                first_name: cartData.first_name || '',
                                last_name: cartData.last_name || ''
                            }
                        };
                        
                        console.log('Checkout data:', checkoutData);
                        
                        // Stuur naar myPOS API
                        return fetch(MYPOS_API_URL, {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                            },
                            body: JSON.stringify(checkoutData)
                        });
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success && data.checkout_url) {
                            // Redirect naar myPOS checkout
                            window.location.href = data.checkout_url;
                        } else {
                            throw new Error(data.error || 'Checkout failed');
                        }
                    })
                    .catch(error => {
                        console.error('Checkout error:', error);
                        alert('Er is iets misgegaan bij het voorbereiden van de betaling. Probeer het opnieuw.');
                        
                        // Reset button
                        button.textContent = originalText;
                        button.disabled = false;
                    });
            });
        });
    });
})();
