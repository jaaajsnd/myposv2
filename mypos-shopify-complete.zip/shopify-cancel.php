<?php
/**
 * Shopify Cancel - Redirect terug naar Shopify bij geannuleerde betaling
 */

$shopDomain = $_GET['shop'] ?? 'jouw-winkel.myshopify.com';

// Redirect terug naar Shopify cart
$shopifyCartUrl = "https://{$shopDomain}/cart";

?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Betaling Geannuleerd</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .container {
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            max-width: 500px;
            width: 100%;
            padding: 40px;
            text-align: center;
        }
        
        .cancel-icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            position: relative;
        }
        
        .cancel-icon::before,
        .cancel-icon::after {
            content: '';
            position: absolute;
            width: 40px;
            height: 4px;
            background: white;
            border-radius: 2px;
        }
        
        .cancel-icon::before {
            transform: rotate(45deg);
        }
        
        .cancel-icon::after {
            transform: rotate(-45deg);
        }
        
        h1 {
            color: #333;
            margin-bottom: 10px;
            font-size: 24px;
        }
        
        p {
            color: #666;
            margin-bottom: 30px;
            line-height: 1.6;
        }
        
        .btn {
            display: inline-block;
            padding: 14px 32px;
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            transition: transform 0.2s ease;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(240, 147, 251, 0.3);
        }
    </style>
    <script>
        // Auto-redirect na 5 seconden
        setTimeout(function() {
            window.location.href = '<?php echo htmlspecialchars($shopifyCartUrl); ?>';
        }, 5000);
    </script>
</head>
<body>
    <div class="container">
        <div class="cancel-icon"></div>
        <h1>Betaling Geannuleerd</h1>
        <p>
            Je hebt de betaling geannuleerd. Je winkelwagen blijft bewaard.
            Je wordt teruggestuurd naar de winkel...
        </p>
        <a href="<?php echo htmlspecialchars($shopifyCartUrl); ?>" class="btn">
            Terug naar winkelwagen
        </a>
    </div>
</body>
</html>
