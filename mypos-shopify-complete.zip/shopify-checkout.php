<?php
/**
 * Shopify to myPOS Checkout API
 * Deze file ontvangt cart data van Shopify en stuurt door naar myPOS
 */

// CORS headers voor Shopify
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

// Handle OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/config.php';

// Log voor debugging
$logFile = __DIR__ . '/checkout_requests.log';

try {
    // Lees de JSON data van Shopify
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);
    
    // Log de request
    file_put_contents(
        $logFile,
        date('[Y-m-d H:i:s] ') . "Shopify checkout request:\n" . 
        print_r($data, true) . 
        "\n---\n",
        FILE_APPEND
    );
    
    // Valideer de data
    if (!$data || !isset($data['items']) || !isset($data['total'])) {
        throw new Exception('Ongeldige cart data ontvangen');
    }
    
    // Haal configuratie op
    $cnf = getMyPosConfig();
    
    // Maak een nieuwe Purchase aan
    $purchase = new \Mypos\IPC\Purchase($cnf);
    
    // Genereer uniek order nummer
    $orderID = 'SHOPIFY-' . time() . '-' . rand(1000, 9999);
    
    // Stel order details in
    $purchase->setOrderID($orderID);
    $purchase->setCurrency($data['currency'] ?? 'EUR');
    $purchase->setAmount($data['total']); // Totaalbedrag van Shopify
    
    // URL's - pas aan naar jouw Shopify store!
    $shopifyDomain = $data['shop_domain'] ?? 'jouw-winkel.myshopify.com';
    
    $baseUrl = getBaseUrl();
    $purchase->setUrlCancel($baseUrl . '/shopify-cancel.php?shop=' . urlencode($shopifyDomain));
    $purchase->setUrlOk($baseUrl . '/shopify-success.php?shop=' . urlencode($shopifyDomain) . '&order=' . $orderID);
    $purchase->setUrlNotify($baseUrl . '/callback.php');
    
    // Klantgegevens (optioneel)
    if (isset($data['customer'])) {
        $customer = new \Mypos\IPC\Customer();
        
        if (!empty($data['customer']['email'])) {
            $customer->setEmail($data['customer']['email']);
        }
        if (!empty($data['customer']['first_name'])) {
            $customer->setFirstName($data['customer']['first_name']);
        }
        if (!empty($data['customer']['last_name'])) {
            $customer->setLastName($data['customer']['last_name']);
        }
        
        $purchase->setCustomer($customer);
    }
    
    // Voeg cart items toe
    $cart = new \Mypos\IPC\Cart();
    foreach ($data['items'] as $item) {
        $cart->add(
            $item['title'] ?? 'Product',
            $item['quantity'] ?? 1,
            $item['price'] ?? 0
        );
    }
    $purchase->setCart($cart);
    
    // Valideer de purchase
    $purchase->validate();
    
    // Genereer de redirect URL
    $redirectUrl = $purchase->process();
    
    // Stuur de URL terug naar Shopify
    echo json_encode([
        'success' => true,
        'checkout_url' => $redirectUrl,
        'order_id' => $orderID
    ]);
    
} catch (Exception $e) {
    // Log de error
    file_put_contents(
        $logFile,
        date('[Y-m-d H:i:s] ') . "ERROR: " . $e->getMessage() . "\n",
        FILE_APPEND
    );
    
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
