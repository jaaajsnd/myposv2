# myPOS Checkout voor Shopify - Complete Gids

## 📋 Wat is dit?

Dit is een **complete werkende integratie** tussen jouw Shopify webshop en myPOS betalingen. Klanten kunnen producten in hun winkelwagen stoppen en afrekenen via myPOS in plaats van Shopify Payments.

## 🔐 Hoe weet myPOS dat het jouw webshop is?

**Het configuratiepakket!** In `config.php` staat:

```php
$cnf->loadConfigurationPackage('eyJzaWQiOiIxMjMxNDkyIiw...');
```

Deze lange string bevat:
- **Jouw Store ID (SID)**: `1231492` - Uniek voor jouw myPOS account
- **Jouw Private Key**: Voor het ondertekenen van betalingen
- **Jouw Certificaat**: Voor encryptie en validatie

Dit heb je gekregen toen je je myPOS account aanmaakte. Het is al gekoppeld!

---

## 🚀 Installatie Stap voor Stap

### STAP 1: Deploy naar Render.com

1. Ga naar [render.com](https://render.com) en log in
2. Klik op **"New +"** → **"Web Service"**
3. Kies **"Deploy from GitHub"** (of upload ZIP)
4. Upload deze bestanden
5. Settings:
   - **Name**: `mypos-shopify-checkout` (of wat je wilt)
   - **Environment**: `Docker` of `Native`
   - **Build Command**: `composer install` (kan leeg)
   - **Start Command**: `php -S 0.0.0.0:$PORT`
6. Klik **"Create Web Service"**

Je krijgt een URL zoals: `https://mypos-shopify-checkout.onrender.com`

**💡 Let op:** Render free tier "slaapt" na 15 minuten inactiviteit. Voor productie gebruik betaalde plan of Railway.app.

---

### STAP 2: Pas config.php aan

Open `config.php` en wijzig:

```php
function getBaseUrl() {
    return 'https://mypos-shopify-checkout.onrender.com'; // ← Jouw Render URL!
}
```

---

### STAP 3: Shopify Theme Aanpassen

#### A. Installeer het JavaScript

1. In Shopify admin: **Online Store** → **Themes**
2. Klik op **"Actions"** → **"Edit code"**
3. Zoek `theme.liquid` of `cart.liquid`
4. Plak dit VOOR de `</body>` tag:

```html
<script>
// myPOS Checkout Integration
const MYPOS_API_URL = 'https://mypos-shopify-checkout.onrender.com/shopify-checkout.php';

document.addEventListener('DOMContentLoaded', function() {
    const checkoutButtons = document.querySelectorAll('button[name="checkout"], .checkout-button');
    
    checkoutButtons.forEach(function(button) {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            
            const originalText = button.textContent;
            button.textContent = 'Betaling voorbereiden...';
            button.disabled = true;
            
            fetch('/cart.js')
                .then(response => response.json())
                .then(cartData => {
                    const checkoutData = {
                        shop_domain: Shopify.shop,
                        total: (cartData.total_price / 100).toFixed(2),
                        currency: cartData.currency,
                        items: cartData.items.map(item => ({
                            title: item.product_title,
                            quantity: item.quantity,
                            price: (item.price / 100).toFixed(2)
                        }))
                    };
                    
                    return fetch(MYPOS_API_URL, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(checkoutData)
                    });
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        window.location.href = data.checkout_url;
                    } else {
                        throw new Error(data.error);
                    }
                })
                .catch(error => {
                    alert('Fout bij betaling: ' + error.message);
                    button.textContent = originalText;
                    button.disabled = false;
                });
        });
    });
});
</script>
```

5. Klik **"Save"**

#### B. Maak een Success Pagina in Shopify (Optioneel maar aangeraden)

1. Ga naar **Online Store** → **Pages**
2. Klik **"Add page"**
3. Title: `Payment Success`
4. Content:
```html
<div class="payment-success">
  <h1>✅ Betaling Geslaagd!</h1>
  <p>Bedankt voor je bestelling!</p>
  <p id="order-details"></p>
  <a href="/" class="button">Verder winkelen</a>
</div>

<script>
  const params = new URLSearchParams(window.location.search);
  const orderId = params.get('order_id');
  const amount = params.get('amount');
  
  if (orderId) {
    document.getElementById('order-details').innerHTML = 
      'Order nummer: ' + orderId + '<br>Bedrag: €' + amount;
  }
</script>
```
5. Save en noteer de URL (bijv. `/pages/payment-success`)

---

### STAP 4: Test de Integratie

#### A. Test URL's
Controleer of deze werken:
- `https://jouw-render-url.onrender.com/shopify-checkout.php` (moet "Method not allowed" of iets geven)
- `https://jouw-render-url.onrender.com/callback.php` (moet leeg zijn)

#### B. Test de flow:
1. Ga naar je Shopify winkel
2. Voeg producten toe aan winkelwagen
3. Klik op checkout button
4. Je moet naar myPOS worden doorgestuurd
5. Gebruik myPOS test kaart
6. Check of je terugkomt bij Shopify

---

## 🔧 Hoe werkt de flow?

```
┌─────────────────────────────────────────────────────────────┐
│                    SHOPIFY WEBSHOP                          │
│  Klant voegt producten toe aan winkelwagen (€50)           │
└────────────────────────┬────────────────────────────────────┘
                         │ Klikt "Checkout"
                         ▼
┌─────────────────────────────────────────────────────────────┐
│              JAVASCRIPT IN SHOPIFY THEME                    │
│  - Haalt cart data op via /cart.js                         │
│  - Stuurt JSON naar jouw Render server                     │
│    { total: "50.00", items: [...], currency: "EUR" }       │
└────────────────────────┬────────────────────────────────────┘
                         │ POST request
                         ▼
┌─────────────────────────────────────────────────────────────┐
│          JOUW PHP SERVER (Render.com)                       │
│  shopify-checkout.php:                                      │
│  - Ontvangt cart data                                       │
│  - Maakt myPOS Purchase object                             │
│  - Bedrag: €50.00 (uit Shopify cart)                       │
│  - Genereert checkout URL                                   │
└────────────────────────┬────────────────────────────────────┘
                         │ Redirect URL terug
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                    MYPOS BETAALPAGINA                       │
│  Klant voert kaartgegevens in en betaalt €50               │
└────────────────────────┬────────────────────────────────────┘
                         │ Na betaling
                         ▼
┌─────────────────────────────────────────────────────────────┐
│          SHOPIFY-SUCCESS.PHP (Render)                       │
│  - Valideert myPOS response                                │
│  - Redirect naar Shopify success page                      │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────┐
│              TERUG IN SHOPIFY                               │
│  Klant ziet bevestiging: "Bestelling €50 succesvol!"       │
└─────────────────────────────────────────────────────────────┘

PARALLEL: myPOS stuurt ook notificatie naar callback.php
          (server-to-server, klant ziet dit niet)
```

---

## 📊 Data Flow Voorbeeld

### Request van Shopify naar PHP:
```json
{
  "shop_domain": "jouw-winkel.myshopify.com",
  "total": "50.00",
  "currency": "EUR",
  "items": [
    {
      "title": "T-shirt Blauw",
      "quantity": 2,
      "price": "25.00"
    }
  ]
}
```

### Response van PHP naar Shopify:
```json
{
  "success": true,
  "checkout_url": "https://mypos.com/vmp/checkout/?order=abc123...",
  "order_id": "SHOPIFY-1733234567-4892"
}
```

---

## 🐛 Problemen Oplossen

### Probleem: "CORS error" in browser console

**Oplossing:** Check of `shopify-checkout.php` de juiste CORS headers heeft:
```php
header('Access-Control-Allow-Origin: https://jouw-winkel.myshopify.com');
```

---

### Probleem: Render app "slaapt"

**Symptomen:** Eerste checkout duurt 30+ seconden

**Oplossing 1:** Gebruik Render betaalde plan (altijd online)

**Oplossing 2:** Gebruik **Railway.app** of **Heroku** (betere free tier)

**Oplossing 3:** Ping je Render URL elke 10 minuten (met cron job):
```bash
*/10 * * * * curl https://jouw-app.onrender.com/ping.php
```

---

### Probleem: Bedragen kloppen niet

**Check:**
1. Shopify geeft prijzen in **centen** (5000 = €50.00)
2. JavaScript converteert: `(cartData.total_price / 100).toFixed(2)`
3. Controleer logs: `checkout_requests.log` op server

---

### Probleem: Checkout button werkt niet

**Check:**
1. Is JavaScript correct geplakt in theme?
2. Staat de juiste `MYPOS_API_URL` in het script?
3. Open browser console (F12) en kijk naar errors
4. Check of button selector klopt: 
   ```javascript
   document.querySelectorAll('button[name="checkout"]')
   ```

---

## 📝 Logging & Debugging

Alle logs worden opgeslagen in:
- `checkout_requests.log` - Alle inkomende Shopify requests
- `mypos_callbacks.log` - Notificaties van myPOS
- `shopify_payments.log` - Succesvolle betalingen

Download deze bestanden van Render:
1. Ga naar je service in Render dashboard
2. Klik op **"Shell"** tab
3. Run: `cat checkout_requests.log`

---

## 🌍 Alternatieve Hosting Opties

### Railway.app (Aanbevolen voor productie)
```bash
# 1. Install Railway CLI
npm install -g @railway/cli

# 2. Login
railway login

# 3. Deploy
railway up
```

Voordelen:
- ✅ Geen cold starts
- ✅ Betere performance  
- ✅ $5/maand gratis

---

### Heroku
1. Create new app in dashboard
2. Connect GitHub repo
3. Deploy

---

### Shared Hosting (Bijv. TransIP, Hostinger)
Gewoon uploaden via FTP! Goedkoopst (€3-5/maand) en werkt prima.

---

## 🔒 Beveiliging Checklist voor Productie

- [ ] Gebruik HTTPS (SSL certificaat)
- [ ] Valideer altijd myPOS signatures in callback.php
- [ ] Log IP adressen van requests
- [ ] Whitelist alleen jouw Shopify domein in CORS
- [ ] Gebruik environment variables voor gevoelige data
- [ ] Monitor logs dagelijks
- [ ] Backup configuratiepakket

---

## 💰 Kosten Overzicht

### Render.com
- Free: $0/maand (met cold starts)
- Starter: $7/maand (altijd online)

### Railway.app  
- Free: $5 credit/maand
- Pro: $5/maand (altijd online)

### Shared Hosting
- €3-7/maand (geen cold starts)

**Aanbeveling:** Start met Render free, upgrade later naar Railway of shared hosting.

---

## 🎯 Volgende Stappen

1. ✅ Deploy naar Render
2. ✅ Test met €0.01 transactie
3. ✅ Voeg JavaScript toe aan Shopify
4. ✅ Test volledige flow
5. ✅ Schakel over naar productie
6. ✅ Monitor eerste paar dagen intensief
7. ✅ Ga live!

---

## 📞 Hulp Nodig?

### Render Logs Bekijken
1. Ga naar Render dashboard
2. Klik je service
3. Tab "Logs" - hier zie je alle PHP errors

### Test Endpoints
```bash
# Test of API werkt:
curl -X POST https://jouw-app.onrender.com/shopify-checkout.php \
  -H "Content-Type: application/json" \
  -d '{"total":"10.00","currency":"EUR","items":[]}'
```

### Shopify Cart.js Debuggen
Open je Shopify winkel en run in console:
```javascript
fetch('/cart.js').then(r => r.json()).then(console.log)
```

---

## ✨ Extra Features (Optioneel)

### Email Notificaties
Voeg toe aan `callback.php`:
```php
if ($status == 0) {
    mail(
        'jouw@email.nl',
        'Nieuwe bestelling €' . $amount,
        'Order: ' . $orderID
    );
}
```

### Slack Notificaties
```php
if ($status == 0) {
    $webhook = 'https://hooks.slack.com/services/...';
    $message = json_encode(['text' => 'Betaling €' . $amount]);
    file_get_contents($webhook, false, stream_context_create([
        'http' => ['method' => 'POST', 'content' => $message]
    ]));
}
```

Succes met je Shopify + myPOS integratie! 🎉
