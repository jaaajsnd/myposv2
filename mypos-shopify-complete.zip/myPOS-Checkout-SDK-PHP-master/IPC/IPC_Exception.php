<?php

namespace Mypos\IPC;

class IPC_Exception extends \Exception
{
    #TODO
}
